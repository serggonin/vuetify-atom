'use babel';

import VuetifyAtomView from '../lib/vuetify-atom-view';

describe('VuetifyAtomView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
